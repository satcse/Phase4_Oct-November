import { SpantextDirective } from './spantext.directive';

describe('SpantextDirective', () => {
  it('should create an instance', () => {
    const directive = new SpantextDirective();
    expect(directive).toBeTruthy();
  });
});

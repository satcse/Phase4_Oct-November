import { SqrtPipePipe } from './sqrt-pipe.pipe';

describe('SqrtPipePipe', () => {
  it('create an instance', () => {
    const pipe = new SqrtPipePipe();
    expect(pipe).toBeTruthy();
  });
});
